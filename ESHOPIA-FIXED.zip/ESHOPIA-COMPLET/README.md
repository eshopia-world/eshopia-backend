# 🛒 E-Shopia Maroc — Projet Complet v8

## 📁 Structure du projet

```
ESHOPIA-COMPLET/
├── frontend/                    ← Netlify (HTML/CSS/JS)
│   ├── index.html               ← Homepage
│   ├── sw.js                    ← Service Worker (cache)
│   ├── netlify.toml             ← Config Netlify
│   ├── css/
│   │   ├── style.css            ← Styles + RTL arabe
│   │   └── megamenu.css
│   ├── js/
│   │   ├── i18n.js              ← FR/AR/EN (193 clés)
│   │   ├── script.js            ← Logique + Links system
│   │   ├── api.js               ← Appels backend
│   │   ├── features.js          ← Tracking, Flash deals
│   │   └── pwa.js               ← PWA + notifications
│   └── pages/
│       ├── product.html         ← Bundle + FAQ + Pixels
│       ├── categories.html      ← Toutes les catégories
│       ├── thank-you.html       ← Pixels FB/GA + Upsell
│       ├── checkout.html        ← COD → thank-you
│       ├── tracking.html        ← Suivi commande réel
│       ├── affiliate.html       ← Programme affilié
│       ├── vendor.html          ← Marketplace vendeur
│       ├── affiliate-dashboard.html
│       ├── vendor-dashboard.html
│       ├── dashboard.html       ← Admin complet
│       ├── cart.html
│       ├── category.html
│       └── compte.html
│
└── backend/                     ← Render (Node.js)
    ├── package.json
    ├── .env.example
    ├── scripts/seed.js
    └── src/
        ├── server.js
        ├── middleware/
        │   ├── auth.js
        │   ├── errorHandler.js
        │   └── rateLimiter.js
        ├── models/
        │   ├── User.js
        │   ├── Order.js
        │   ├── Product.js
        │   ├── Affiliate.js
        │   └── Vendor.js
        ├── routes/
        │   ├── auth.js
        │   ├── orders.js
        │   ├── products.js
        │   ├── affiliate.js
        │   ├── marketplace.js
        │   ├── agents.js
        │   ├── tracking.js
        │   ├── analytics.js
        │   └── delivery.js
        ├── services/
        │   ├── fraudService.js
        │   ├── notifyService.js
        │   └── scheduler.js
        └── utils/
            └── logger.js
```

---

## 🚀 Déploiement — 4 étapes

### Étape 1 — MongoDB Atlas (gratuit)
1. cloud.mongodb.com → Cluster M0 gratuit
2. Créer user DB → noter le mot de passe
3. Network Access → Allow from anywhere (0.0.0.0/0)
4. Copier la connection string

### Étape 2 — Backend sur Render
1. Pousser le dossier `backend/` sur GitHub
2. render.com → New Web Service → connecter GitHub
3. Build: `npm install` | Start: `npm start`
4. Ajouter variables d'environnement (voir .env.example)

### Étape 3 — Seed Database
Dans Render Shell ou localement:
```bash
cd backend
npm install
node scripts/seed.js
```

### Étape 4 — Frontend sur Netlify
Glisser-déposer le contenu de `frontend/` sur Netlify

---

## 🔐 Comptes après seed

| Rôle | Email | Mot de passe |
|---|---|---|
| superadmin | admin@eshopia.ma | Admin@2024! |
| agent | sara@eshopia.ma | Agent@2024! |
| agent | karim@eshopia.ma | Agent@2024! |
| client | client@eshopia.ma | Client@2024! |

---

## 📊 Tracking Pixels

Dans `pages/thank-you.html`, décommenter et remplir:
```javascript
fbq('init', 'VOTRE_PIXEL_ID_FACEBOOK');
gtag('config', 'G-VOTRE_GA4_ID');
```

---

## 🌍 Langues

Changer la langue: boutons FR / ع / EN dans la navbar
RTL automatique pour l'arabe (police Cairo)

---

## 📞 Support

WhatsApp: +212 702 010 303
Email: support@eshopia.ma
