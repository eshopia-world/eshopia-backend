'use strict';
/* ============================================================
   E-SHOPIA — i18n.js v2
   Langues: Français / العربية / English
   RTL automatique pour l'arabe
   ============================================================ */

const i18n = (()=>{
  const T = {
    fr:{
      nav_search_ph:"Rechercher produits, marques, modèles…",
      nav_cart:"Panier", nav_login:"Se connecter", nav_account:"Mon compte",
      add_to_cart:"Ajouter au panier", buy_now:"Commander maintenant",
      in_stock:"En stock", out_of_stock:"Rupture de stock",
      free_delivery:"Livraison gratuite dès 129 DH", cod:"Paiement à la livraison",
      cart_title:"Mon Panier", cart_empty:"Votre panier est vide",
      cart_total:"Total", cart_checkout:"Passer la commande",
      checkout_title:"Informations de livraison",
      field_name:"Nom complet", field_phone:"Téléphone",
      field_city:"Ville", field_address:"Adresse complète",
      btn_order:"Confirmer ma commande",
      order_success:"Commande confirmée ! Nous vous rappellerons sous peu.",
      section_flash:"Ventes Flash du Jour",
      section_featured:"Produits En Vedette",
      section_bestsellers:"Meilleures Ventes",
      section_combos:"Offres Bundle",
      section_categories:"Parcourir par Catégorie",
      section_reviews:"Avis Vérifiés",
      section_affiliate:"Gagnez de l'argent en recommandant nos produits",
      toast_added:"Produit ajouté au panier !",
      toast_removed:"Produit retiré",
      toast_ordered:"Commande confirmée !",
      order_confirmed_title:"Commande Confirmée ! 🎉",
      order_confirmed_sub:"Merci pour votre achat. Notre équipe vous contactera sous peu.",
      footer_about:"À propos", footer_contact:"Contact",
      footer_affiliate:"Programme Affilié", footer_terms:"CGU",
      footer_privacy:"Confidentialité",
    },
    ar:{
      nav_search_ph:"ابحث عن منتجات، ماركات، موديلات…",
      nav_cart:"السلة", nav_login:"تسجيل الدخول", nav_account:"حسابي",
      add_to_cart:"أضف إلى السلة", buy_now:"اشتري الآن",
      in_stock:"متوفر في المخزن", out_of_stock:"نفذ من المخزن",
      free_delivery:"توصيل مجاني من 129 درهم", cod:"الدفع عند الاستلام",
      cart_title:"سلة المشتريات", cart_empty:"سلتك فارغة",
      cart_total:"المجموع", cart_checkout:"إتمام الطلب",
      checkout_title:"معلومات التوصيل",
      field_name:"الاسم الكامل", field_phone:"رقم الهاتف",
      field_city:"المدينة", field_address:"العنوان الكامل",
      btn_order:"تأكيد الطلب",
      order_success:"تم تأكيد طلبك! سنتصل بك قريباً.",
      section_flash:"عروض اليوم المحدودة",
      section_featured:"منتجات مميزة",
      section_bestsellers:"الأكثر مبيعاً",
      section_combos:"عروض مجمعة",
      section_categories:"تصفح حسب الفئة",
      section_reviews:"تقييمات موثقة",
      section_affiliate:"اربح المال بالتوصية بمنتجاتنا",
      toast_added:"تمت إضافة المنتج إلى السلة!",
      toast_removed:"تمت إزالة المنتج",
      toast_ordered:"تم تأكيد طلبك!",
      order_confirmed_title:"تم تأكيد طلبك! 🎉",
      order_confirmed_sub:"شكراً لشرائك. سيتصل بك فريقنا قريباً.",
      footer_about:"من نحن", footer_contact:"اتصل بنا",
      footer_affiliate:"برنامج الإحالة", footer_terms:"الشروط والأحكام",
      footer_privacy:"سياسة الخصوصية",
    },
    en:{
      nav_search_ph:"Search products, brands, models…",
      nav_cart:"Cart", nav_login:"Sign in", nav_account:"My account",
      add_to_cart:"Add to cart", buy_now:"Buy now",
      in_stock:"In stock", out_of_stock:"Out of stock",
      free_delivery:"Free delivery from 129 DH", cod:"Cash on delivery",
      cart_title:"My Cart", cart_empty:"Your cart is empty",
      cart_total:"Total", cart_checkout:"Checkout",
      checkout_title:"Delivery information",
      field_name:"Full name", field_phone:"Phone",
      field_city:"City", field_address:"Full address",
      btn_order:"Confirm my order",
      order_success:"Order confirmed! We will call you shortly.",
      section_flash:"Flash Deals Today",
      section_featured:"Featured Products",
      section_bestsellers:"Best Sellers",
      section_combos:"Bundle Offers",
      section_categories:"Browse by Category",
      section_reviews:"Verified Reviews",
      section_affiliate:"Earn money recommending our products",
      toast_added:"Product added to cart!",
      toast_removed:"Product removed",
      toast_ordered:"Order confirmed!",
      order_confirmed_title:"Order Confirmed! 🎉",
      order_confirmed_sub:"Thank you for your purchase. Our team will contact you shortly.",
      footer_about:"About", footer_contact:"Contact",
      footer_affiliate:"Affiliate program", footer_terms:"Terms",
      footer_privacy:"Privacy policy",
    }
  };

  function detect(){
    const saved = localStorage.getItem('eshopia_lang');
    if(saved && T[saved]) return saved;
    const br = navigator.language?.slice(0,2).toLowerCase();
    if(br==='ar') return 'ar';
    if(br==='en') return 'en';
    return 'fr';
  }

  let lang = detect();

  function apply(l){
    lang = l;
    localStorage.setItem('eshopia_lang', l);
    document.documentElement.setAttribute('lang', l);
    const rtl = l==='ar';
    document.documentElement.setAttribute('dir', rtl?'rtl':'ltr');
    document.body.classList.toggle('rtl', rtl);

    if(rtl){
      if(!document.getElementById('cairo-font')){
        const lk = document.createElement('link');
        lk.id='cairo-font'; lk.rel='stylesheet';
        lk.href='https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap';
        document.head.appendChild(lk);
      }
      document.body.style.setProperty('--fb',"'Cairo',sans-serif");
      document.body.style.setProperty('--fh',"'Cairo',sans-serif");
    } else {
      document.body.style.removeProperty('--fb');
      document.body.style.removeProperty('--fh');
    }

    /* Translate data-i18n elements */
    document.querySelectorAll('[data-i18n]').forEach(el=>{
      const k=el.getAttribute('data-i18n');
      if(T[l]?.[k]) el.textContent=T[l][k];
    });
    document.querySelectorAll('[data-i18n-ph]').forEach(el=>{
      const k=el.getAttribute('data-i18n-ph');
      if(T[l]?.[k]) el.placeholder=T[l][k];
    });
    /* Update active button */
    document.querySelectorAll('.lang-btn').forEach(b=>{
      b.classList.toggle('lang-active', b.dataset.lang===l);
    });
  }

  function buildSwitcher(containerId){
    const el=document.getElementById(containerId);
    if(!el) return;
    el.innerHTML=`<div class="lang-sw">
      <button class="lang-btn${lang==='fr'?' lang-active':''}" data-lang="fr" onclick="i18n.set('fr')">FR</button>
      <button class="lang-btn${lang==='ar'?' lang-active':''}" data-lang="ar" onclick="i18n.set('ar')">ع</button>
      <button class="lang-btn${lang==='en'?' lang-active':''}" data-lang="en" onclick="i18n.set('en')">EN</button>
    </div>`;
  }

  document.addEventListener('DOMContentLoaded',()=>apply(lang));

  return {
    t:(k)=>T[lang]?.[k]||T.fr[k]||k,
    set:apply,
    get:()=>lang,
    price:(n)=>lang==='ar'?`${n} درهم`:lang==='en'?`${n} MAD`:`${n} DH`,
    buildSwitcher,
  };
})();
