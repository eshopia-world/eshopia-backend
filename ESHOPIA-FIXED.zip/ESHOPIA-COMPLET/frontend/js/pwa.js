'use strict';
/* ============================================================
   E-SHOPIA — PWA System
   Install prompt, offline support, push notifications
   ============================================================ */

// Register service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('[PWA] SW registered'))
      .catch(err => console.warn('[PWA] SW failed:', err));
  });
}

// Install prompt
let deferredPrompt = null;
const PWA = {
  init() {
    window.addEventListener('beforeinstallprompt', e => {
      e.preventDefault();
      deferredPrompt = e;
      PWA.showBanner();
    });
    window.addEventListener('appinstalled', () => {
      PWA.hideBanner();
      if (window.toast) toast('E-Shopia installée sur votre téléphone !', 'success');
    });
  },
  showBanner() {
    if (document.getElementById('pwa-banner')) return;
    const banner = document.createElement('div');
    banner.id = 'pwa-banner';
    banner.innerHTML = `
      <div style="position:fixed;bottom:70px;left:12px;right:12px;background:#0f172a;color:#fff;border-radius:16px;padding:14px 16px;display:flex;align-items:center;gap:12px;z-index:9999;box-shadow:0 8px 32px rgba(0,0,0,.35);animation:slideUp .3s ease">
        <img src="/images/logo.png" style="width:40px;height:40px;border-radius:8px;object-fit:contain;background:#fff">
        <div style="flex:1">
          <div style="font-weight:700;font-size:.85rem">Installer E-Shopia</div>
          <div style="font-size:.75rem;opacity:.7">Accès rapide depuis votre écran d'accueil</div>
        </div>
        <button onclick="PWA.install()" style="background:#1565c0;color:#fff;border:none;padding:8px 14px;border-radius:10px;font-size:.78rem;font-weight:700;cursor:pointer">Installer</button>
        <button onclick="PWA.hideBanner()" style="background:transparent;color:rgba(255,255,255,.5);border:none;font-size:1.2rem;cursor:pointer;padding:0 4px">×</button>
      </div>`;
    document.body.appendChild(banner);
  },
  hideBanner() {
    document.getElementById('pwa-banner')?.remove();
  },
  async install() {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    deferredPrompt = null;
    PWA.hideBanner();
  }
};

// Add slideUp animation
const style = document.createElement('style');
style.textContent = '@keyframes slideUp{from{transform:translateY(20px);opacity:0}to{transform:translateY(0);opacity:1}}';
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', () => PWA.init());
